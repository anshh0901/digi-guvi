// StudySync India Digital Marketing Strategy Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('StudySync India Dashboard Initializing...');
    
    // Initialize the dashboard
    initializeNavigation();
    initializeChannelCards();
    initializeBudgetBreakdown();
    initializeExportFunction();
    initializeProgressBars();
    initializeIndianFeatures();
    
    console.log('StudySync India Dashboard Initialized Successfully!');
});

// Navigation functionality - Fixed to properly show/hide sections
function initializeNavigation() {
    const navTabs = document.querySelectorAll('.nav-tab');
    const sections = document.querySelectorAll('.section');

    console.log(`Found ${navTabs.length} navigation tabs and ${sections.length} sections`);

    navTabs.forEach((tab, index) => {
        console.log(`Tab ${index}: ${tab.getAttribute('data-section')}`);
        
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const targetSection = this.getAttribute('data-section');
            console.log(`Clicked tab for section: ${targetSection}`);
            
            // Remove active class from all tabs and sections
            navTabs.forEach(t => t.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Find and show the corresponding section
            const targetElement = document.getElementById(targetSection);
            console.log(`Target element found:`, targetElement);
            
            if (targetElement) {
                targetElement.classList.add('active');
                
                // Smooth scroll to top of section
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
                
                // Special handling for different sections
                if (targetSection === 'kpis') {
                    setTimeout(() => animateProgressBars(), 300);
                }
                
                if (targetSection === 'market') {
                    setTimeout(() => loadMarketData(), 100);
                }
                
                // Show success feedback
                showNotification(`Navigated to ${targetSection} section`, 'success');
            } else {
                console.error(`Section with ID '${targetSection}' not found`);
                showNotification(`Error: Section '${targetSection}' not found`, 'error');
            }
        });
    });

    // Ensure Executive Summary is shown by default
    const executiveSection = document.getElementById('executive');
    const executiveTab = document.querySelector('[data-section="executive"]');
    
    if (executiveSection && executiveTab) {
        executiveSection.classList.add('active');
        executiveTab.classList.add('active');
        console.log('Executive Summary set as default active section');
    }
}

// Channel cards expandable functionality
function initializeChannelCards() {
    const channelCards = document.querySelectorAll('.channel-card.expandable');
    console.log(`Found ${channelCards.length} expandable channel cards`);
    
    channelCards.forEach((card, index) => {
        const expandBtn = card.querySelector('.expand-btn');
        const channelDetails = card.querySelector('.channel-details');
        
        console.log(`Channel card ${index}:`, { expandBtn: !!expandBtn, channelDetails: !!channelDetails });
        
        if (expandBtn && channelDetails) {
            expandBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const isExpanded = !channelDetails.classList.contains('hidden');
                console.log(`Toggling channel card ${index}, currently expanded: ${isExpanded}`);
                
                if (isExpanded) {
                    // Collapse
                    channelDetails.classList.add('hidden');
                    this.textContent = '+';
                    this.style.transform = 'rotate(0deg)';
                } else {
                    // Expand
                    channelDetails.classList.remove('hidden');
                    this.textContent = '−';
                    this.style.transform = 'rotate(180deg)';
                }
                
                // Add animation class to card
                card.style.transition = 'all 0.3s ease';
                
                // Show feedback
                const action = isExpanded ? 'collapsed' : 'expanded';
                showNotification(`Channel details ${action}`, 'info');
            });
        }
    });
}

// Budget breakdown interactive functionality with Indian amounts
function initializeBudgetBreakdown() {
    const breakdownItems = document.querySelectorAll('.breakdown-item');
    console.log(`Found ${breakdownItems.length} budget breakdown items`);
    
    breakdownItems.forEach((item, index) => {
        const channel = item.getAttribute('data-channel');
        console.log(`Budget item ${index}: ${channel}`);
        
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const channelType = this.getAttribute('data-channel');
            console.log(`Clicked budget item: ${channelType}`);
            showChannelDetails(channelType);
        });
        
        // Add hover effects with Indian color scheme
        item.addEventListener('mouseenter', function() {
            this.style.backgroundColor = 'rgba(255, 153, 51, 0.1)';
            this.style.borderColor = '#138808';
            this.style.transform = 'translateX(6px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.backgroundColor = 'var(--color-surface)';
            this.style.borderColor = '#FF9933';
            this.style.transform = 'translateX(0)';
        });
    });
}

// Show channel details when budget item is clicked
function showChannelDetails(channelType) {
    console.log(`Showing details for channel: ${channelType}`);
    
    // Switch to channels section
    const channelsTab = document.querySelector('[data-section="channels"]');
    const channelsSection = document.getElementById('channels');
    
    if (channelsTab && channelsSection) {
        // Update navigation
        document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
        
        channelsTab.classList.add('active');
        channelsSection.classList.add('active');
        
        // Smooth scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Find and highlight the specific channel card
        const targetCard = document.querySelector(`.channel-card[data-channel="${channelType}"]`);
        if (targetCard) {
            // Scroll to the card
            setTimeout(() => {
                targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                // Highlight the card with Indian colors
                targetCard.style.boxShadow = '0 0 25px rgba(255, 153, 51, 0.4)';
                targetCard.style.transform = 'scale(1.03)';
                targetCard.style.borderColor = '#138808';
                
                // Remove highlight after animation
                setTimeout(() => {
                    targetCard.style.boxShadow = '';
                    targetCard.style.transform = '';
                    targetCard.style.borderColor = '#FF9933';
                }, 2500);
            }, 300);
            
            showNotification(`Navigated to ${channelType} channel details`, 'success');
        } else {
            console.log(`Channel card for ${channelType} not found`);
            showNotification(`Channel details for ${channelType} loaded`, 'success');
        }
    } else {
        console.error('Channels section or tab not found');
        showNotification('Error navigating to channels section', 'error');
    }
}

// Progress bars animation
function initializeProgressBars() {
    const progressBars = document.querySelectorAll('.progress');
    console.log(`Found ${progressBars.length} progress bars`);
    
    // Store original widths
    progressBars.forEach((bar, index) => {
        const width = bar.style.width;
        bar.setAttribute('data-width', width);
        bar.style.width = '0%';
        console.log(`Progress bar ${index} initialized with target width: ${width}`);
    });
}

function animateProgressBars() {
    const progressBars = document.querySelectorAll('.progress');
    console.log('Animating progress bars...');
    
    progressBars.forEach((bar, index) => {
        const targetWidth = bar.getAttribute('data-width');
        
        setTimeout(() => {
            bar.style.width = targetWidth;
            console.log(`Progress bar ${index} animated to ${targetWidth}`);
        }, index * 250);
    });
}

// Indian market specific features
function initializeIndianFeatures() {
    console.log('Initializing Indian market features...');
    
    // Add rupee symbol formatting
    formatIndianCurrency();
    
    // Initialize WhatsApp Business analytics
    initializeWhatsAppAnalytics();
    
    // Set up regional tracking
    setupRegionalTracking();
    
    // Initialize festival marketing calendar
    initializeFestivalCalendar();
}

// Format currency values to Indian rupees
function formatIndianCurrency() {
    const currencyElements = document.querySelectorAll('.metric-value, .amount, .roi-value');
    console.log(`Formatting ${currencyElements.length} currency elements`);
    
    currencyElements.forEach(element => {
        if (element.textContent.includes('₹') && !element.textContent.includes(',')) {
            const value = element.textContent.replace('₹', '').replace(/,/g, '');
            if (!isNaN(value) && value.length > 3) {
                const formattedValue = '₹' + formatIndianNumber(parseInt(value));
                element.textContent = formattedValue;
                console.log(`Formatted currency: ${value} -> ${formattedValue}`);
            }
        }
    });
}

// Indian number formatting (lakhs and crores)
function formatIndianNumber(num) {
    if (num >= 10000000) { // 1 crore
        return (num / 10000000).toFixed(1) + ' Cr';
    } else if (num >= 100000) { // 1 lakh
        return (num / 100000).toFixed(1) + ' L';
    } else if (num >= 1000) {
        return num.toLocaleString('en-IN');
    }
    return num.toString();
}

// WhatsApp Business analytics initialization
function initializeWhatsAppAnalytics() {
    const whatsappMetrics = {
        contacts: 6000,
        target: 10000,
        openRate: 92,
        responseRate: 45
    };
    
    console.log('WhatsApp Business Metrics Initialized:', whatsappMetrics);
    updateWhatsAppUI(whatsappMetrics);
}

function updateWhatsAppUI(metrics) {
    // Update WhatsApp specific UI elements if they exist
    const whatsappElements = document.querySelectorAll('[data-metric="whatsapp"]');
    whatsappElements.forEach(element => {
        // Update UI elements with WhatsApp metrics
    });
    console.log('WhatsApp Business Metrics UI Updated:', metrics);
}

// Regional tracking setup for Indian cities
function setupRegionalTracking() {
    const indianCities = [
        'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai',
        'Pune', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Lucknow'
    ];
    
    // Simulate regional performance data
    const regionalData = indianCities.map(city => ({
        city: city,
        users: Math.floor(Math.random() * 1000) + 200,
        conversionRate: (Math.random() * 15 + 5).toFixed(1)
    }));
    
    console.log('Regional Tracking Data Loaded for cities:', regionalData);
}

// Festival marketing calendar
function initializeFestivalCalendar() {
    const indianFestivals = [
        { name: 'Diwali', month: 'October/November', campaign: 'Special Learning Offers' },
        { name: 'Dussehra', month: 'September/October', campaign: 'Victory in Learning' },
        { name: 'Holi', month: 'March', campaign: 'Colorful Learning Journey' },
        { name: 'Eid', month: 'Varies', campaign: 'Celebrate Success' },
        { name: 'Karva Chauth', month: 'October/November', campaign: 'Learn Together' }
    ];
    
    console.log('Festival Marketing Calendar Loaded:', indianFestivals);
}

// Load market data for market context section
function loadMarketData() {
    const marketData = {
        currentMarketSize: '₹62,275 Cr',
        projectedSize2033: '₹2,40,900 Cr',
        cagr: '28.7%',
        whatsappUsers: '487.5M',
        youtubeUsers: '250M',
        instagramUsers: '229.5M'
    };
    
    console.log('Indian EdTech Market Data Loaded:', marketData);
}

// Export functionality with Indian market data
function initializeExportFunction() {
    const exportBtn = document.getElementById('exportBtn');
    console.log('Export button found:', !!exportBtn);
    
    if (exportBtn) {
        exportBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Export button clicked');
            
            // Show loading state with Indian context
            const originalText = this.textContent;
            this.textContent = 'भारतीय रणनीति तैयार कर रहे हैं... (Generating Indian Strategy...)';
            this.disabled = true;
            this.style.opacity = '0.7';
            
            console.log('Starting export process...');
            
            // Simulate export process
            setTimeout(() => {
                try {
                    generateIndianStrategySummary();
                    
                    // Reset button
                    this.textContent = originalText;
                    this.disabled = false;
                    this.style.opacity = '1';
                    
                    // Show success feedback in Hindi and English
                    showNotification('भारतीय रणनीति सफलतापूर्वक तैयार! (Indian strategy generated successfully!)', 'success');
                    console.log('Export completed successfully');
                } catch (error) {
                    console.error('Export error:', error);
                    
                    // Reset button on error
                    this.textContent = originalText;
                    this.disabled = false;
                    this.style.opacity = '1';
                    
                    showNotification('Export failed. Please try again.', 'error');
                }
            }, 2500);
        });
    } else {
        console.error('Export button not found');
    }
}

// Generate and download Indian strategy summary
function generateIndianStrategySummary() {
    console.log('Generating Indian strategy summary...');
    
    const summaryData = {
        company: "StudySync India",
        tagline: "AI-Powered Personalized Learning for Every Indian Student",
        totalBudget: "₹7,14,000/month",
        timeline: "4 weeks (Indian market adapted)",
        marketSize: "₹62,275 crores (2024)",
        channels: [
            { name: "SEO & Content Marketing (Hindi + English)", budget: "₹1,78,500", percentage: "25%", priority: "High", focus: "JEE/NEET/Board exams" },
            { name: "Social Media Marketing (WhatsApp Focus)", budget: "₹1,42,800", percentage: "20%", priority: "High", focus: "WhatsApp Business + Instagram" },
            { name: "Paid Advertising (Regional)", budget: "₹1,28,520", percentage: "18%", priority: "Medium", focus: "Google Ads + Facebook India" },
            { name: "Email + WhatsApp Marketing", budget: "₹1,07,100", percentage: "15%", priority: "Medium", focus: "Bilingual campaigns" },
            { name: "Analytics & Tools (Indian + Global)", budget: "₹71,400", percentage: "10%", priority: "High", focus: "Regional analytics" },
            { name: "Influencer & Partnerships", budget: "₹57,120", percentage: "8%", priority: "Medium", focus: "Educational YouTubers" },
            { name: "Experimental/Testing", budget: "₹28,560", percentage: "4%", priority: "Medium", focus: "Regional platforms" }
        ],
        projections: {
            month1: { customers: 250, revenue: "₹1,24,750", cac: "₹1,800", ltv: "₹18,000", note: "Higher user base due to lower pricing" },
            month3: { customers: 850, revenue: "₹4,24,150", cac: "₹1,650", ltv: "₹19,500", note: "Strong growth in Tier 2/3 cities" },
            month6: { customers: 2100, revenue: "₹10,47,900", cac: "₹1,400", ltv: "₹21,000", note: "Market leadership in affordable EdTech" }
        },
        competitors: [
            { name: "BYJU'S", pricing: "₹2,500+/month", advantage: "5x more affordable" },
            { name: "Unacademy", pricing: "₹1,500+/month", advantage: "AI-powered personalization" },
            { name: "Vedantu", pricing: "₹1,200+/month", advantage: "Better mobile experience" },
            { name: "PhysicsWallah", pricing: "₹800+/month", advantage: "More comprehensive AI features" }
        ]
    };
    
    // Create downloadable content
    const summaryText = formatIndianSummaryForDownload(summaryData);
    downloadTextFile('StudySync_India_Digital_Marketing_Strategy.txt', summaryText);
    
    console.log('Summary generated and download initiated');
}

// Format Indian summary data for download
function formatIndianSummaryForDownload(data) {
    let summary = `STUDYSYNC INDIA DIGITAL MARKETING STRATEGY SUMMARY
${'='.repeat(60)}
🇮🇳 Bharat Ki Digital Shiksha Kranti (India's Digital Education Revolution)

COMPANY OVERVIEW - कंपनी विवरण
Company: ${data.company}
Tagline: ${data.tagline}
Total Monthly Budget: ${data.totalBudget}
Implementation Timeline: ${data.timeline}
Indian EdTech Market Size: ${data.marketSize}

BUDGET ALLOCATION - बजट आवंटन
${'-'.repeat(40)}
`;

    data.channels.forEach(channel => {
        summary += `${channel.name}: ${channel.budget} (${channel.percentage}) - ${channel.priority} Priority
   Focus: ${channel.focus}\n\n`;
    });

    summary += `
FINANCIAL PROJECTIONS - वित्तीय अनुमान
${'-'.repeat(40)}
Month 1: ${data.projections.month1.customers} customers, ${data.projections.month1.revenue} revenue
        CAC: ${data.projections.month1.cac}, LTV: ${data.projections.month1.ltv}
        Note: ${data.projections.month1.note}

Month 3: ${data.projections.month3.customers} customers, ${data.projections.month3.revenue} revenue
        CAC: ${data.projections.month3.cac}, LTV: ${data.projections.month3.ltv}
        Note: ${data.projections.month3.note}

Month 6: ${data.projections.month6.customers} customers, ${data.projections.month6.revenue} revenue
        CAC: ${data.projections.month6.cac}, LTV: ${data.projections.month6.ltv}
        Note: ${data.projections.month6.note}

KEY INDIAN MARKET METRICS - मुख्य भारतीय बाजार मेट्रिक्स
${'-'.repeat(40)}
- Customer Acquisition Cost: < ₹2,000 (optimized for Indian purchasing power)
- Return on Ad Spend: 4:1 ROAS
- LTV:CAC Ratio: 15:1 (higher due to lower pricing)
- Monthly Growth Rate: 85% (aggressive growth in Indian market)
- Payback Period: 2.1 months
- WhatsApp Business Reach: 10,000 contacts target
- Regional Keyword Rankings: Top 10 for 75 education keywords
- Mobile Traffic Share: 85%+ (critical for Indian market)

COMPETITIVE POSITIONING - प्रतिस्पर्धी स्थिति
${'-'.repeat(40)}
`;

    data.competitors.forEach(competitor => {
        summary += `${competitor.name}: ${competitor.pricing} | Our Advantage: ${competitor.advantage}\n`;
    });

    summary += `
IMPLEMENTATION PHASES - कार्यान्वयन चरण
${'-'.repeat(40)}
Week 1: Foundation & Localization (₹1,78,500 - 25%)
- Regional language content setup
- WhatsApp Business profile creation
- Festival calendar integration

Week 2: Content & Regional SEO Launch (₹2,14,200 - 30%)
- JEE/NEET/Board exam content
- Mobile-first SEO optimization
- Hindi + English content publication

Week 3: Scale & Student Engagement (₹2,49,900 - 35%)
- College ambassador program
- Payment gateway optimization
- Viral educational content for Instagram Reels

Week 4: Analysis & Festival Marketing (₹71,400 - 10%)
- Regional performance analysis
- Festival marketing campaigns
- A/B testing for regional languages

INDIAN MARKET ADVANTAGES - भारतीय बाजार के फायदे
${'-'.repeat(40)}
✓ Most affordable AI-powered EdTech platform in India
✓ Bilingual content (Hindi + English) strategy
✓ WhatsApp Business integration for maximum reach
✓ Mobile-first approach for Tier 1/2/3 cities
✓ Festival marketing calendar integration
✓ Regional payment gateway optimization
✓ Educational exam season planning (JEE, NEET, Board)
✓ Tier 1/2/3 city targeting strategies

TARGET CITIES - लक्षित शहर
Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Pune, Kolkata, Ahmedabad, Jaipur, Lucknow

Generated on: ${new Date().toLocaleDateString('en-IN')}
Report prepared for Indian EdTech market domination 🚀

धन्यवाद! (Thank you!)
StudySync India - Making Quality Education Accessible to Every Indian Student
`;

    return summary;
}

// Download text file
function downloadTextFile(filename, text) {
    try {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
        
        console.log(`File ${filename} download initiated`);
        return true;
    } catch (error) {
        console.error('Download error:', error);
        return false;
    }
}

// Show notification with Indian styling
function showNotification(message, type = 'info') {
    console.log(`Showing notification: ${message} (${type})`);
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #138808, #FF9933);
        color: white;
        padding: var(--space-12) var(--space-16);
        border-radius: var(--radius-base);
        box-shadow: 0 8px 25px rgba(255, 153, 51, 0.3);
        z-index: 1000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        border: 2px solid #000080;
        font-weight: 500;
        max-width: 350px;
        word-wrap: break-word;
        font-size: 14px;
        line-height: 1.4;
    `;
    
    if (type === 'error') {
        notification.style.background = 'linear-gradient(135deg, #FF4444, #000080)';
    } else if (type === 'success') {
        notification.style.background = 'linear-gradient(135deg, #138808, #FF9933)';
    }
    
    notification.innerHTML = message;
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after delay
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}

// Enhanced hover effects for cards with Indian styling
document.addEventListener('DOMContentLoaded', function() {
    // Add hover effects to summary cards
    const summaryCards = document.querySelectorAll('.summary-card');
    summaryCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.borderColor = '#138808';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.borderColor = '#FF9933';
        });
    });
    
    // Add hover effects to projection cards
    const projectionCards = document.querySelectorAll('.projection-card');
    projectionCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-6px) scale(1.01)';
            this.style.borderColor = '#138808';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.borderColor = '#FF9933';
        });
    });
    
    // Add interactive effects to KPI cards
    const kpiCards = document.querySelectorAll('.kpi-card');
    kpiCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.borderColor = '#138808';
            this.style.boxShadow = '0 4px 15px rgba(255, 153, 51, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.borderColor = '#FF9933';
            this.style.boxShadow = '';
        });
    });
    
    // Add hover effects to competitive analysis cards
    const competitorCards = document.querySelectorAll('.competitor-card');
    competitorCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (this.classList.contains('studysync')) {
                this.style.transform = 'scale(1.05)';
                this.style.boxShadow = '0 8px 25px rgba(19, 136, 8, 0.3)';
            } else {
                this.style.transform = 'scale(1.02)';
                this.style.borderColor = '#138808';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = '';
            if (!this.classList.contains('studysync')) {
                this.style.borderColor = '#FF9933';
            }
        });
    });
});

// Keyboard navigation support with Indian context
document.addEventListener('keydown', function(e) {
    const activeTab = document.querySelector('.nav-tab.active');
    const allTabs = Array.from(document.querySelectorAll('.nav-tab'));
    const currentIndex = allTabs.indexOf(activeTab);
    
    if (e.key === 'ArrowRight' && currentIndex < allTabs.length - 1) {
        e.preventDefault();
        allTabs[currentIndex + 1].click();
    } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
        e.preventDefault();
        allTabs[currentIndex - 1].click();
    }
});

// Performance optimization: Lazy load images with Indian context
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img[src]');
    console.log(`Found ${images.length} images to lazy load`);
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.style.opacity = '0';
                    img.style.transition = 'opacity 0.4s ease';
                    
                    img.onload = function() {
                        this.style.opacity = '1';
                        console.log('Image loaded successfully');
                    };
                    
                    img.onerror = function() {
                        console.error('Image failed to load:', this.src);
                        this.style.opacity = '0.5';
                    };
                    
                    observer.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
    
    // Format Indian currency on load
    setTimeout(() => formatIndianCurrency(), 500);
});

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Run all initialization functions
    console.log('='.repeat(50));
    console.log('StudySync India Dashboard Fully Initialized');
    console.log('Market Focus: Indian EdTech');
    console.log('Currency: Indian Rupees (₹)');
    console.log('Languages: Hindi + English');
    console.log('Target: Tier 1/2/3 cities');
    console.log('Platform Focus: WhatsApp Business + Mobile');
    console.log('='.repeat(50));
    
    // Add loading animation for charts with Indian context
    const charts = document.querySelectorAll('.budget-chart, .market-chart');
    charts.forEach((chart, index) => {
        chart.style.opacity = '0';
        chart.style.transform = 'translateY(20px)';
        chart.style.transition = 'all 0.6s ease';
        chart.style.border = '2px solid #FF9933';
        
        chart.onload = function() {
            this.style.opacity = '1';
            this.style.transform = 'translateY(0)';
            console.log(`Chart ${index + 1} loaded`);
        };
        
        // If image is already loaded
        if (chart.complete) {
            chart.style.opacity = '1';
            chart.style.transform = 'translateY(0)';
        }
    });
    
    // Final setup confirmation
    setTimeout(() => {
        showNotification('स्वागत है! StudySync India Dashboard ready for Indian EdTech domination! 🚀', 'success');
    }, 1000);
});